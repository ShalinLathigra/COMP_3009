/*
Description:
	Program that outputs "hello world"
Copyright (c):
	2021 Sharjeel Ali <sharjeelali@cmail.carleton.ca>
	2016 Doran Nussbaum <nussbaum@scs.carleton.ca>
*/

#include <app.h>


int main(int arg, char ** argv){

	OpenGLApp app;
	app.Init(arg, argv);

}