This week I learned some more of the inner workings of OpenGL, specifically with regards to using the perspective matrix and how to 
alter it to achieve a zoom effect. I also was able to observe firsthand some of the difficulties of tracking position and rotation
in 3D space with only one point of reference.

During my tutorial presentation I attempted to display Pitch/Yaw, however the effect they produced was quite similar to simply 
translating up down left or right at the rate of movement I was using. I wound up thinking I had done something wrong and went back
over my work, only to realize that I just needed a second point of reference to better illustrate the behaviour.